# lambdata
A python package with useful Data Science functions
